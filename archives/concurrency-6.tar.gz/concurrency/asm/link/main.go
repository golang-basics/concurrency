package main

import (
	"fmt"
)

// go tool compile main.go
// go tool link -o exec main.o
// go tool objdump -s main.main exec
func main() {
	fmt.Println("hello world: linking")
}
