package main

import (
	"fmt"
)

// https://github.com/golang/go/blob/master/src/math/sqrt.go#L92
// https://github.com/golang/go/blob/master/src/math/sqrt_asm.go#L12
// https://github.com/golang/go/blob/master/src/math/sqrt_amd64.s#L8
func Sqrt(float64) float64
// https://github.com/golang/go/blob/master/src/math/floor.go#L13
// https://github.com/golang/go/blob/master/src/math/floor_asm.go#L12
// https://github.com/golang/go/blob/master/src/math/floor_amd64.s#L10
func Floor(float64) float64
func ASMPrintResult(float64, float64)

func printResult(sqrtRes, floorRes float64) {
	fmt.Println("sqrt result", sqrtRes)
	fmt.Println("floor result", floorRes)
}

func main() {
	ASMPrintResult(Sqrt(25), Floor(2.33))
}
