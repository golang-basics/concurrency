//+build avoid

package main

func DummyFunc(int) int

func main() {
	DummyFunc(10)
}
